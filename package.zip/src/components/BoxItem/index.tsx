import React from "react";

const BoxItem = () => {
  return (
    <>
      <div></div>
    </>
  );
};

export default BoxItem;
